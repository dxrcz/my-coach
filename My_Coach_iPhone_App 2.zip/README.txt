MY COACH — personal iPhone PWA

This is Version 1. Open index.html through a web host (not directly from Files) and then use Safari > Share > Add to Home Screen.

Data is stored locally in the browser. This version includes Home, Goals, Workout logging, Progress, daily tasks and a basic coach message.
